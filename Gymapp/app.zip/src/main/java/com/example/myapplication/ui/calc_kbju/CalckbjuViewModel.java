package com.example.myapplication.ui.calc_kbju;

import androidx.lifecycle.ViewModel;

public class CalckbjuViewModel extends ViewModel
{
    // TODO: Implement the ViewModel
}
