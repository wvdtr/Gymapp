package com.example.myapplication.ui.calc_sil;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.myapplication.R;
import com.example.myapplication.StrengthRecord;
import com.example.myapplication.SupabaseClient;

import java.lang.Integer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CalcsilFragment extends Fragment
{
    private String currentExercise = "";
    private int currentOneRepMax = 0;
    
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        View v = inflater.inflate(R.layout.fragment_calc_sil, container, false);

        EditText calc_sil_weight, calc_sil_repeats, exerciseInput;
        calc_sil_weight = v.findViewById(R.id.edittext_calc_sil_weight);
        calc_sil_repeats = v.findViewById(R.id.edittext_calc_sil_repeats);
        exerciseInput = v.findViewById(R.id.edittext_exercise_name);

        TextView answer;
        answer = v.findViewById(R.id.text_calc_sil_1pm);

        Button button, saveButton, viewRecordsButton;
        button = v.findViewById(R.id.button_calc_sil);
        saveButton = v.findViewById(R.id.button_save_record);
        viewRecordsButton = v.findViewById(R.id.button_view_records);
        
        saveButton.setEnabled(false);

        button.setOnClickListener(v1 ->
        {
            String weight = calc_sil_weight.getText().toString(), repeats = (calc_sil_repeats.getText()).toString();
            currentExercise = exerciseInput.getText().toString();
            
            if (currentExercise.isEmpty()) {
                Toast.makeText(getContext(), "Please enter exercise name", Toast.LENGTH_SHORT).show();
                return;
            }
            
            int w, r;
            try
            {
                w = Integer.parseInt(weight);
            }
            catch (NumberFormatException exception)
            {
                w = 0;
            }
            try
            {
                r = Integer.parseInt(repeats);
            }
            catch (NumberFormatException exception)
            {
                r = 0;
            }
            String ans = "";
            if (r == 1) {
                currentOneRepMax = w;
                ans = "Ваш 1ПМ равен " + Integer.toString(w) + "\n" + "Ваш 2ПМ равен " + Integer.toString((int)(w * 0.95)) + "\n" + "Ваш 3ПМ равен " + Integer.toString((int) (w * 0.93)) + "\n" +
                        "Ваш 4ПМ равен " + Integer.toString((int)(w * 0.90)) + "\n" + "Ваш 5ПМ равен " + Integer.toString((int)(w * 0.87)) + "\n" +
                        "Ваш 6ПМ равен " + Integer.toString((int) (w * 0.85)) + "\n" + "Ваш 7ПМ равен " + Integer.toString((int)(w * 0.83)) + "\n" +
                        "Ваш 8ПМ равен " + Integer.toString((int)(w * 0.80)) + "\n" + "Ваш 9ПМ равен " + Integer.toString((int) (w * 0.77)) + "\n";
            }
            else if (r == 2) {
                currentOneRepMax = (int)(w / 0.95);
                ans = "Ваш 1ПМ равен " + Integer.toString(currentOneRepMax) + "\n" + "Ваш 2ПМ равен " + Integer.toString(w) + "\n" + "Ваш 3ПМ равен " + Integer.toString((int) (w / 0.95 * 0.93)) + "\n" +
                        "Ваш 4ПМ равен " + Integer.toString((int)(w / 0.95 * 0.90)) + "\n" + "Ваш 5ПМ равен " + Integer.toString((int)(w / 0.95 * 0.87)) + "\n" +
                        "Ваш 6ПМ равен " + Integer.toString((int)(w / 0.95 * 0.85)) + "\n" + "Ваш 7ПМ равен " + Integer.toString((int)(w / 0.95 * 0.83)) + "\n" +
                        "Ваш 8ПМ равен " + Integer.toString((int)(w / 0.95 * 0.80)) + "\n" + "Ваш 9ПМ равен " + Integer.toString((int)(w / 0.95 * 0.77)) + "\n";
            }
            else if (r == 3) {
                currentOneRepMax = (int)(w / 0.93);
                ans = "Ваш 1ПМ равен " + Integer.toString(currentOneRepMax) + "\n" + "Ваш 2ПМ равен " + Integer.toString((int)(w / 0.93 * 0.95)) + "\n" + "Ваш 3ПМ равен " + Integer.toString(w) + "\n" +
                        "Ваш 4ПМ равен " + Integer.toString((int)(w / 0.93 * 0.90)) + "\n" + "Ваш 5ПМ равен " + Integer.toString((int)(w / 0.93 * 0.87)) + "\n" +
                        "Ваш 6ПМ равен " + Integer.toString((int)(w / 0.93 * 0.85)) + "\n" + "Ваш 7ПМ равен " + Integer.toString((int)(w / 0.93 * 0.83)) + "\n" +
                        "Ваш 8ПМ равен " + Integer.toString((int)(w / 0.93 * 0.80)) + "\n" + "Ваш 9ПМ равен " + Integer.toString((int)(w / 0.93 * 0.77)) + "\n";
            }
            else if (r == 4) {
                currentOneRepMax = (int)(w / 0.9);
                ans = "Ваш 1ПМ равен " + Integer.toString(currentOneRepMax) + "\n" + "Ваш 2ПМ равен " + Integer.toString((int)(w / 0.9 * 0.95)) + "\n" + "Ваш 3ПМ равен " + Integer.toString((int)(w / 0.9 * 0.93)) + "\n" +
                        "Ваш 4ПМ равен " + Integer.toString(w) + "\n" + "Ваш 5ПМ равен " + Integer.toString((int)(w / 0.9 * 0.87)) + "\n" +
                        "Ваш 6ПМ равен " + Integer.toString((int)(w / 0.9 * 0.85)) + "\n" + "Ваш 7ПМ равен " + Integer.toString((int)(w / 0.9 * 0.83)) + "\n" +
                        "Ваш 8ПМ равен " + Integer.toString((int)(w / 0.9 * 0.80)) + "\n" + "Ваш 9ПМ равен " + Integer.toString((int)(w / 0.9 * 0.77)) + "\n";
            }
            else if (r == 5) {
                currentOneRepMax = (int)(w / 0.87);
                ans = "Ваш 1ПМ равен " + Integer.toString(currentOneRepMax) + "\n" + "Ваш 2ПМ равен " + Integer.toString((int)(w / 0.87 * 0.95)) + "\n" + "Ваш 3ПМ равен " + Integer.toString((int)(w / 0.87 * 0.93)) + "\n" +
                        "Ваш 4ПМ равен " + Integer.toString((int)(w / 0.87 * 0.90)) + "\n" + "Ваш 5ПМ равен " + Integer.toString(w) + "\n" +
                        "Ваш 6ПМ равен " + Integer.toString((int)(w / 0.87 * 0.85)) + "\n" + "Ваш 7ПМ равен " + Integer.toString((int)(w / 0.87 * 0.83)) + "\n" +
                        "Ваш 8ПМ равен " + Integer.toString((int)(w / 0.87 * 0.80)) + "\n" + "Ваш 9ПМ равен " + Integer.toString((int)(w / 0.87 * 0.77)) + "\n";
            }
            else if (r == 6) {
                currentOneRepMax = (int)(w / 0.85);
                ans = "Ваш 1ПМ равен " + Integer.toString(currentOneRepMax) + "\n" + "Ваш 2ПМ равен " + Integer.toString((int)(w / 0.85 * 0.95)) + "\n" + "Ваш 3ПМ равен " + Integer.toString((int)(w / 0.85 * 0.93)) + "\n" +
                        "Ваш 4ПМ равен " + Integer.toString((int)(w / 0.85 * 0.90)) + "\n" + "Ваш 5ПМ равен " + Integer.toString((int)(w / 0.85 * 0.87)) + "\n" +
                        "Ваш 6ПМ равен " + Integer.toString(w) + "\n" + "Ваш 7ПМ равен " + Integer.toString((int)(w / 0.85 * 0.83)) + "\n" +
                        "Ваш 8ПМ равен " + Integer.toString((int)(w / 0.85 * 0.80)) + "\n" + "Ваш 9ПМ равен " + Integer.toString((int)(w / 0.85 * 0.77)) + "\n";
            }
            else if (r == 7) {
                currentOneRepMax = (int)(w / 0.83);
                ans = "Ваш 1ПМ равен " + Integer.toString(currentOneRepMax) + "\n" + "Ваш 2ПМ равен " + Integer.toString((int)(w / 0.83 * 0.95)) + "\n" + "Ваш 3ПМ равен " + Integer.toString((int)(w / 0.83 * 0.93)) + "\n" +
                        "Ваш 4ПМ равен " + Integer.toString((int)(w / 0.83 * 0.90)) + "\n" + "Ваш 5ПМ равен " + Integer.toString((int)(w / 0.83 * 0.87)) + "\n" +
                        "Ваш 6ПМ равен " + Integer.toString((int)(w / 0.83 * 0.85)) + "\n" + "Ваш 7ПМ равен " + Integer.toString(w) + "\n" +
                        "Ваш 8ПМ равен " + Integer.toString((int)(w / 0.83 * 0.80)) + "\n" + "Ваш 9ПМ равен " + Integer.toString((int)(w / 0.83 * 0.77)) + "\n";
            }
            else if (r == 8) {
                currentOneRepMax = (int)(w / 0.8);
                ans = "Ваш 1ПМ равен " + Integer.toString(currentOneRepMax) + "\n" + "Ваш 2ПМ равен " + Integer.toString((int)(w / 0.8 * 0.95)) + "\n" + "Ваш 3ПМ равен " + Integer.toString((int)(w / 0.8 * 0.93)) + "\n" +
                        "Ваш 4ПМ равен " + Integer.toString((int)(w / 0.8 * 0.90)) + "\n" + "Ваш 5ПМ равен " + Integer.toString((int)(w / 0.8 * 0.87)) + "\n" +
                        "Ваш 6ПМ равен " + Integer.toString((int)(w / 0.8 * 0.85)) + "\n" + "Ваш 7ПМ равен " + Integer.toString((int)(w / 0.8 * 0.83)) + "\n" +
                        "Ваш 8ПМ равен " + Integer.toString(w) + "\n" + "Ваш 9ПМ равен " + Integer.toString((int)(w / 0.8 * 0.77)) + "\n";
            }
            else if (r == 9) {
                currentOneRepMax = (int)(w / 0.77);
                ans = "Ваш 1ПМ равен " + Integer.toString(currentOneRepMax) + "\n" + "Ваш 2ПМ равен " + Integer.toString((int)(w / 0.77 * 0.95)) + "\n" + "Ваш 3ПМ равен " + Integer.toString((int)(w / 0.77 * 0.93)) + "\n" +
                        "Ваш 4ПМ равен " + Integer.toString((int)(w / 0.77 * 0.90)) + "\n" + "Ваш 5ПМ равен " + Integer.toString((int)(w / 0.77 * 0.87)) + "\n" +
                        "Ваш 6ПМ равен " + Integer.toString((int)(w / 0.77 * 0.85)) + "\n" + "Ваш 7ПМ равен " + Integer.toString((int)(w / 0.77 * 0.83)) + "\n" +
                        "Ваш 8ПМ равен " + Integer.toString((int)(w / 0.77 * 0.80)) + "\n" + "Ваш 9ПМ равен " + Integer.toString(w) + "\n";
            }
            else if (r == 10) {
                currentOneRepMax = (int)(w / 0.75);
                ans = "Ваш 1ПМ равен " + Integer.toString(currentOneRepMax) + "\n" + "Ваш 2ПМ равен " + Integer.toString((int)(w / 0.75 * 0.95)) + "\n" + "Ваш 3ПМ равен " + Integer.toString((int)(w / 0.75 * 0.93)) + "\n" +
                        "Ваш 4ПМ равен " + Integer.toString((int)(w / 0.75 * 0.90)) + "\n" + "Ваш 5ПМ равен " + Integer.toString((int)(w / 0.75 * 0.87)) + "\n" +
                        "Ваш 6ПМ равен " + Integer.toString((int)(w / 0.75 * 0.85)) + "\n" + "Ваш 7ПМ равен " + Integer.toString((int)(w / 0.75 * 0.83)) + "\n" +
                        "Ваш 8ПМ равен " + Integer.toString((int)(w / 0.75 * 0.80)) + "\n" + "Ваш 9ПМ равен " + Integer.toString((int)(w / 0.75 * 0.77)) + "\n";
            }
            answer.setText(ans);
            
            // Enable save button if we have a valid one rep max
            if (currentOneRepMax > 0 && !currentExercise.isEmpty()) {
                saveButton.setEnabled(true);
            }
        });
        
        saveButton.setOnClickListener(v1 -> {
            if (currentOneRepMax > 0 && !currentExercise.isEmpty()) {
                StrengthRecord record = new StrengthRecord(currentExercise, currentOneRepMax);
                saveStrengthRecord(record);
            } else {
                Toast.makeText(getContext(), "Please calculate your one rep max first", Toast.LENGTH_SHORT).show();
            }
        });
        
        viewRecordsButton.setOnClickListener(v1 -> {
            // Navigate to the database fragment to view records
            requireActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.nav_host_fragment_activity_main, new com.example.myapplication.ui.database.DatabaseFragment())
                    .addToBackStack(null)
                    .commit();
        });
        
        return v;
    }
    
    private void saveStrengthRecord(StrengthRecord record) {
        SupabaseClient.getInstance().addStrengthRecord(record, new SupabaseClient.SupabaseCallback<Boolean>() {
            @Override
            public void onSuccess(Boolean result) {
                requireActivity().runOnUiThread(() -> {
                    Toast.makeText(getContext(), "Strength record saved successfully", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onError(String error) {
                requireActivity().runOnUiThread(() -> {
                    Toast.makeText(getContext(), "Error saving strength record: " + error, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }
}
