package com.example.myapplication;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class StrengthRecord {
    private int id;
    private String exercise;
    private int oneRepMax;
    private String date;
    
    public StrengthRecord(int id, String exercise, int oneRepMax, String date) {
        this.id = id;
        this.exercise = exercise;
        this.oneRepMax = oneRepMax;
        this.date = date;
    }
    
    public StrengthRecord(String exercise, int oneRepMax) {
        this.exercise = exercise;
        this.oneRepMax = oneRepMax;
        this.date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }
    
    public int getId() {
        return id;
    }
    
    public String getExercise() {
        return exercise;
    }
    
    public int getOneRepMax() {
        return oneRepMax;
    }
    
    public String getDate() {
        return date;
    }
}
