package com.example.myapplication;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SupabaseClient {
    private static final String TAG = "SupabaseClient";
    private static final String SUPABASE_URL = "YOUR_SUPABASE_URL";
    private static final String SUPABASE_KEY = "YOUR_SUPABASE_API_KEY";
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    
    private static SupabaseClient instance;
    private final OkHttpClient client;
    
    private SupabaseClient() {
        client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
    }
    
    public static synchronized SupabaseClient getInstance() {
        if (instance == null) {
            instance = new SupabaseClient();
        }
        return instance;
    }
    
    // Product methods
    public void getProducts(final SupabaseCallback<List<Product>> callback) {
        Request request = new Request.Builder()
                .url(SUPABASE_URL + "/rest/v1/products?select=*")
                .addHeader("apikey", SUPABASE_KEY)
                .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                .build();
                
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Failed to fetch products", e);
                callback.onError(e.getMessage());
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    callback.onError("Failed to fetch products: " + response.code());
                    return;
                }
                
                try {
                    String responseData = response.body().string();
                    JSONArray jsonArray = new JSONArray(responseData);
                    List<Product> products = new ArrayList<>();
                    
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        Product product = new Product(
                                jsonObject.getInt("id"),
                                jsonObject.getString("name"),
                                jsonObject.getDouble("calories"),
                                jsonObject.getDouble("protein"),
                                jsonObject.getDouble("fat"),
                                jsonObject.getDouble("carbs")
                        );
                        products.add(product);
                    }
                    
                    callback.onSuccess(products);
                } catch (JSONException e) {
                    Log.e(TAG, "Failed to parse products", e);
                    callback.onError("Failed to parse products: " + e.getMessage());
                }
            }
        });
    }
    
    public void addProduct(Product product, final SupabaseCallback<Boolean> callback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("name", product.getName());
            jsonObject.put("calories", product.getCalories());
            jsonObject.put("protein", product.getProtein());
            jsonObject.put("fat", product.getFat());
            jsonObject.put("carbs", product.getCarbs());
            
            RequestBody body = RequestBody.create(jsonObject.toString(), JSON);
            
            Request request = new Request.Builder()
                    .url(SUPABASE_URL + "/rest/v1/products")
                    .addHeader("apikey", SUPABASE_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=minimal")
                    .post(body)
                    .build();
                    
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Failed to add product", e);
                    callback.onError(e.getMessage());
                }
                
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        callback.onSuccess(true);
                    } else {
                        callback.onError("Failed to add product: " + response.code());
                    }
                }
            });
        } catch (JSONException e) {
            Log.e(TAG, "Failed to create product JSON", e);
            callback.onError(e.getMessage());
        }
    }
    
    public void deleteProduct(int id, final SupabaseCallback<Boolean> callback) {
        Request request = new Request.Builder()
                .url(SUPABASE_URL + "/rest/v1/products?id=eq." + id)
                .addHeader("apikey", SUPABASE_KEY)
                .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                .delete()
                .build();
                
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Failed to delete product", e);
                callback.onError(e.getMessage());
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    callback.onSuccess(true);
                } else {
                    callback.onError("Failed to delete product: " + response.code());
                }
            }
        });
    }
    
    // Strength record methods
    public void getStrengthRecords(final SupabaseCallback<List<StrengthRecord>> callback) {
        Request request = new Request.Builder()
                .url(SUPABASE_URL + "/rest/v1/strength_records?select=*")
                .addHeader("apikey", SUPABASE_KEY)
                .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                .build();
                
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Failed to fetch strength records", e);
                callback.onError(e.getMessage());
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    callback.onError("Failed to fetch strength records: " + response.code());
                    return;
                }
                
                try {
                    String responseData = response.body().string();
                    JSONArray jsonArray = new JSONArray(responseData);
                    List<StrengthRecord> records = new ArrayList<>();
                    
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        StrengthRecord record = new StrengthRecord(
                                jsonObject.getInt("id"),
                                jsonObject.getString("exercise"),
                                jsonObject.getInt("one_rep_max"),
                                jsonObject.getString("date")
                        );
                        records.add(record);
                    }
                    
                    callback.onSuccess(records);
                } catch (JSONException e) {
                    Log.e(TAG, "Failed to parse strength records", e);
                    callback.onError("Failed to parse strength records: " + e.getMessage());
                }
            }
        });
    }
    
    public void addStrengthRecord(StrengthRecord record, final SupabaseCallback<Boolean> callback) {
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("exercise", record.getExercise());
            jsonObject.put("one_rep_max", record.getOneRepMax());
            jsonObject.put("date", record.getDate());
            
            RequestBody body = RequestBody.create(jsonObject.toString(), JSON);
            
            Request request = new Request.Builder()
                    .url(SUPABASE_URL + "/rest/v1/strength_records")
                    .addHeader("apikey", SUPABASE_KEY)
                    .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Prefer", "return=minimal")
                    .post(body)
                    .build();
                    
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Failed to add strength record", e);
                    callback.onError(e.getMessage());
                }
                
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        callback.onSuccess(true);
                    } else {
                        callback.onError("Failed to add strength record: " + response.code());
                    }
                }
            });
        } catch (JSONException e) {
            Log.e(TAG, "Failed to create strength record JSON", e);
            callback.onError(e.getMessage());
        }
    }
    
    public void deleteStrengthRecord(int id, final SupabaseCallback<Boolean> callback) {
        Request request = new Request.Builder()
                .url(SUPABASE_URL + "/rest/v1/strength_records?id=eq." + id)
                .addHeader("apikey", SUPABASE_KEY)
                .addHeader("Authorization", "Bearer " + SUPABASE_KEY)
                .delete()
                .build();
                
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Failed to delete strength record", e);
                callback.onError(e.getMessage());
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    callback.onSuccess(true);
                } else {
                    callback.onError("Failed to delete strength record: " + response.code());
                }
            }
        });
    }
    
    public interface SupabaseCallback<T> {
        void onSuccess(T result);
        void onError(String error);
    }
}
