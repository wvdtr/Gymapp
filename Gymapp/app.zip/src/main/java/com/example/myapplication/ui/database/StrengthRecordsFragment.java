package com.example.myapplication.ui.database;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.StrengthRecord;
import com.example.myapplication.SupabaseClient;
import com.example.myapplication.databinding.FragmentStrengthRecordsBinding;

import java.util.ArrayList;
import java.util.List;

public class StrengthRecordsFragment extends Fragment implements StrengthRecordsAdapter.OnRecordClickListener {

    private FragmentStrengthRecordsBinding binding;
    private RecyclerView recyclerView;
    private StrengthRecordsAdapter adapter;
    private List<StrengthRecord> recordsList = new ArrayList<>();
    private SupabaseClient supabaseClient;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentStrengthRecordsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        supabaseClient = SupabaseClient.getInstance();
        recyclerView = binding.strengthRecordsRecyclerView;
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new StrengthRecordsAdapter(recordsList, this);
        recyclerView.setAdapter(adapter);

        binding.addRecordButton.setOnClickListener(v -> showAddRecordDialog());

        loadRecords();

        return root;
    }

    private void loadRecords() {
        binding.strengthRecordsProgressBar.setVisibility(View.VISIBLE);
        supabaseClient.getStrengthRecords(new SupabaseClient.SupabaseCallback<List<StrengthRecord>>() {
            @Override
            public void onSuccess(List<StrengthRecord> result) {
                requireActivity().runOnUiThread(() -> {
                    binding.strengthRecordsProgressBar.setVisibility(View.GONE);
                    recordsList.clear();
                    recordsList.addAll(result);
                    adapter.notifyDataSetChanged();
                    
                    if (recordsList.isEmpty()) {
                        binding.noRecordsText.setVisibility(View.VISIBLE);
                    } else {
                        binding.noRecordsText.setVisibility(View.GONE);
                    }
                });
            }

            @Override
            public void onError(String error) {
                requireActivity().runOnUiThread(() -> {
                    binding.strengthRecordsProgressBar.setVisibility(View.GONE);
                    Toast.makeText(getContext(), "Error loading records: " + error, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void showAddRecordDialog() {
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_strength_record, null);
        
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Add New Strength Record");
        builder.setView(dialogView);
        
        builder.setPositiveButton("Add", (dialog, which) -> {
            String exercise = ((android.widget.EditText) dialogView.findViewById(R.id.exerciseInput)).getText().toString();
            String oneRepMaxStr = ((android.widget.EditText) dialogView.findViewById(R.id.oneRepMaxInput)).getText().toString();
            
            if (exercise.isEmpty() || oneRepMaxStr.isEmpty()) {
                Toast.makeText(getContext(), "All fields are required", Toast.LENGTH_SHORT).show();
                return;
            }
            
            try {
                int oneRepMax = Integer.parseInt(oneRepMaxStr);
                StrengthRecord record = new StrengthRecord(exercise, oneRepMax);
                addRecord(record);
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), "Invalid number format", Toast.LENGTH_SHORT).show();
            }
        });
        
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void addRecord(StrengthRecord record) {
        binding.strengthRecordsProgressBar.setVisibility(View.VISIBLE);
        supabaseClient.addStrengthRecord(record, new SupabaseClient.SupabaseCallback<Boolean>() {
            @Override
            public void onSuccess(Boolean result) {
                requireActivity().runOnUiThread(() -> {
                    binding.strengthRecordsProgressBar.setVisibility(View.GONE);
                    Toast.makeText(getContext(), "Record added successfully", Toast.LENGTH_SHORT).show();
                    loadRecords();
                });
            }

            @Override
            public void onError(String error) {
                requireActivity().runOnUiThread(() -> {
                    binding.strengthRecordsProgressBar.setVisibility(View.GONE);
                    Toast.makeText(getContext(), "Error adding record: " + error, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    @Override
    public void onRecordClick(StrengthRecord record) {
        new AlertDialog.Builder(getContext())
                .setTitle("Delete Record")
                .setMessage("Are you sure you want to delete this record for " + record.getExercise() + "?")
                .setPositiveButton("Delete", (dialog, which) -> deleteRecord(record.getId()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteRecord(int recordId) {
        binding.strengthRecordsProgressBar.setVisibility(View.VISIBLE);
        supabaseClient.deleteStrengthRecord(recordId, new SupabaseClient.SupabaseCallback<Boolean>() {
            @Override
            public void onSuccess(Boolean result) {
                requireActivity().runOnUiThread(() -> {
                    binding.strengthRecordsProgressBar.setVisibility(View.GONE);
                    Toast.makeText(getContext(), "Record deleted successfully", Toast.LENGTH_SHORT).show();
                    loadRecords();
                });
            }

            @Override
            public void onError(String error) {
                requireActivity().runOnUiThread(() -> {
                    binding.strengthRecordsProgressBar.setVisibility(View.GONE);
                    Toast.makeText(getContext(), "Error deleting record: " + error, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
