package com.example.myapplication.ui.database;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.StrengthRecord;

import java.util.List;

public class StrengthRecordsAdapter extends RecyclerView.Adapter<StrengthRecordsAdapter.RecordViewHolder> {

    private List<StrengthRecord> records;
    private OnRecordClickListener listener;

    public interface OnRecordClickListener {
        void onRecordClick(StrengthRecord record);
    }

    public StrengthRecordsAdapter(List<StrengthRecord> records, OnRecordClickListener listener) {
        this.records = records;
        this.listener = listener;
    }

    @NonNull
    @Override
    public RecordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_strength_record, parent, false);
        return new RecordViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecordViewHolder holder, int position) {
        StrengthRecord record = records.get(position);
        holder.bind(record, listener);
    }

    @Override
    public int getItemCount() {
        return records.size();
    }

    static class RecordViewHolder extends RecyclerView.ViewHolder {
        TextView exerciseTextView;
        TextView oneRepMaxTextView;
        TextView dateTextView;

        public RecordViewHolder(@NonNull View itemView) {
            super(itemView);
            exerciseTextView = itemView.findViewById(R.id.exerciseTextView);
            oneRepMaxTextView = itemView.findViewById(R.id.oneRepMaxTextView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
        }

        public void bind(StrengthRecord record, OnRecordClickListener listener) {
            exerciseTextView.setText(record.getExercise());
            oneRepMaxTextView.setText(record.getOneRepMax() + " кг");
            dateTextView.setText(record.getDate());
            
            itemView.setOnClickListener(v -> listener.onRecordClick(record));
        }
    }
}
